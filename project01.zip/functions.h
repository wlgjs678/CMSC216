/* (c) Larry Herman, 2021.  You are allowed to use this code yourself, but
 * not to provide it to anyone else. */

/* DO NOT MODIFY THIS FILE OR YOUR CODE WILL NOT COMPILE ON THE SUBMIT
 * SERVER. */

int prism_area(int l, int w, int h);
long jacobsthal(short n);
short ith_digit(long n, unsigned short i);
