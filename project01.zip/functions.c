/*
 * This program is intended to provide the three mathematical functions that are prism_area, jacobsthal, and ith_digit.
 * (See the detail for each function)
*/

#include "functions.h"

/* This function calculates the surface area of a rectangular prism.
 * It takes l for length, w for width, and h for height of the prism.
 */
int prism_area(int l, int w, int h) {
  int surface_area = 0;
  if (l == -1 || l == 0) {
    return -1;
  }
  surface_area = 2 * (w * l + l * h +  w * h);
  return surface_area;
}

/* This function returns a jacobsthal number as it takes n to define the size of the sequence.
 * The formula is jacobsthal_n = jacobsthal_(n-1) + 2jacobsthal_(n-2) for n > 1.
 * If n = 0, then jacobsthal_0 = 0. If n = 1, then jacobsthal_1 = 1.
 */
long jacobsthal(short n) {
  long jacobsthal_result;
  if (n < 0) {
    return -1;
  }
  switch (n) {
  case 0:
    jacobsthal_result = 0;
    break;
  case 1:
    jacobsthal_result = 1;
    break;
  default:
    jacobsthal_result = (2 * jacobsthal(n - 2)) + jacobsthal(n - 1);
    break;
  }
  return jacobsthal_result;
}

/* This function returns the ith digit of a number n.
 * It takes arguments n for any positive or negative number and i to define ith digit.
 * (i is always positive)
 */
short ith_digit(long n, unsigned short i) {
  /* div == division */
  long div = 1;
  long positive_n;
  long place_value;
  int index;
  short result;

  /* Set a division value so we can find the ith digit's place value. */
  if (i != 0) {
    for (index = 1; index < i; index++) {
      div *= 10;
    }
  }
  else {
    return -1;
  }

  /* If n is a negative number, convert it to a positive number using the unary operation. */
  if (n < 0) {
    positive_n = -n;
  }
  else {
    positive_n = n;
  }

  /* A number positive_n is divided by div to find its place value. */
  place_value = positive_n / div;
  /* Modulo operation is used to return the value of the ith digit. */
  result = place_value % 10;
  if (result == 0) {
    return -1;
  }
  return result;
}
