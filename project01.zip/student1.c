#include <stdio.h>
#include <assert.h>
#include "functions.h"

/* CMSC 216, Spring 2021, Project #1
 * Public test 1 (public1.c)
 *
 * Tests calling prism_area(1, 1, 1).
 *
 * Note that this test also calls the other two functions but does not check
 * their results for correctness- it calls them only so you will be able to
 * tell that your other functions compile successfully on the submit server.
 * When you are writing your own tests, note that only the first assertion
 * below is actually doing anything (it is an example of how you should be
 * testing your functions yourself, as opposed to what follows it in this
 * test).
 *
 * (c) Larry Herman, 2021.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

int main(void) {
  long result, result2;
  short result3, result4, result5;

  assert(prism_area(1, 1, 1) == 6);
  assert(prism_area(2, 5, 3) == 62);

  result= jacobsthal(1) + ith_digit(1111, 2);
  result2 = jacobsthal(3);
  result3 = ith_digit(1234, 3);
  printf("%hd\n", result3);
  result4 = ith_digit(-1234, 3);
  result5 = ith_digit(1234, 5);
  printf("%hd\n", result5);
  /* this assertion will always be true, regardless of what your
     jacobsthal() and ith_digit() functions return */
  assert(result == 1 || result != 1);
  assert(result2 == 3);
  assert(result3 == 2);
  assert(result5 == -1);
  printf("%hd", result4);
  printf("\nThe test passed!\n");

  return 0;
}
